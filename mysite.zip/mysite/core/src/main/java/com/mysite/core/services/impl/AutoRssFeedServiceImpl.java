package com.mysite.core.services.impl;

import java.io.IOException;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mysite.core.models.AutoRssFeedModel;
import com.mysite.core.models.RssFeed;
import com.mysite.core.models.dto.Item;
import com.mysite.core.models.dto.Rss;
import com.mysite.core.services.AutoRssFeedService;

/**
 * OSGI Service which will make a call to external endpoint and parse the feeds
 * 
 * @author yerriswamyreddyb
 *
 */
@Component(service = AutoRssFeedService.class, immediate = true, name = "RSSFeedServiceImpl")
public class AutoRssFeedServiceImpl implements AutoRssFeedService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AutoRssFeedServiceImpl.class);
	private static final String UTF_8 = "UTF-8";

	@Override
	public List<RssFeed> getUpdates(String sourceUrl) {

		List<RssFeed> autoFeedList = new ArrayList<>();
		String endpointResponse = getResponseFromEndPoint(sourceUrl);
		if (StringUtils.isNotBlank(endpointResponse)) {
			List<Item> formattedList = formatXMLResponse(endpointResponse);
			for (Item item : formattedList) {
				AutoRssFeedModel rssAutoFeedModel = new AutoRssFeedModel();
				rssAutoFeedModel.setTitle(item.getTitle());
				rssAutoFeedModel.setDescription(item.getDescription());
				rssAutoFeedModel.setDate(formatDate(item.getUpdated()));
				autoFeedList.add(rssAutoFeedModel);
			}
		}
		return autoFeedList;
	}

	private String getResponseFromEndPoint(String url) {

		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpGet httpGet = new HttpGet(url);
		String apiResponse = StringUtils.EMPTY;
		try {
			CloseableHttpResponse response = httpClient.execute(httpGet);
			final HttpEntity entity = response.getEntity();
			apiResponse = EntityUtils.toString(entity, UTF_8);
		} catch (IOException e) {
			LOGGER.error("Error in fetching  searchResults");
		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {
				LOGGER.error(
						"Exception occured while fetching feeds from external url in RSSFeedService::getResponseFromEndPoint --> {}",
						e);
			}
		}
		return apiResponse;
	}

	private List<Item> formatXMLResponse(String response) {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(Rss.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			final String formatResponse = response.trim().replaceFirst("^([\\W]+)<", "<");
			StringReader sr = new StringReader(formatResponse);
			Rss rss = (Rss) jaxbUnmarshaller.unmarshal(sr);
			return rss.getChannel().getItems();
		} catch (JAXBException e) {
			LOGGER.error(
					"Exception occured while fetching feeds from external url in RSSFeedService::formatXMLResponse --> {}",
					e);
		}
		return new ArrayList<>();
	}

	private String formatDate(String date) {

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ssX");
		Date result;
		try {
			result = df.parse(date);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			return sdf.format(result);
		} catch (Exception e) {
			LOGGER.error("Error while parsing date {}", e);
		}
		return StringUtils.EMPTY;
	}

}
