package com.mysite.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mysite.core.services.MySiteResourceResolverService;

@Component(service = Servlet.class, property = { SLING_SERVLET_PATHS + "=/bin/utilities/xf-page-sync",
		SLING_SERVLET_METHODS + "=GET" })
public class XFToSiteMsmSynUtilityServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;

	@Reference
	private MySiteResourceResolverService mySiteResourceResolverService;

	private static final String XF_LOCALE_ROOT_PATH = "/content/experience-fragments/mysite/sites/";

	private static final Logger LOGGER = LoggerFactory.getLogger(XFToSiteMsmSynUtilityServlet.class);

	@Override
	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		out.println("<h2>Welcome to XF To Site Sync Utility</h2></br>");
		String sourceXFPath = request.getParameter("sourceXFPath");
		String targetLocales = request.getParameter("targetLocales");
		out.println("Source XF Path:" + sourceXFPath + "</br></br>");
		List<String> targetParentsList = getTargetedLocalePaths(targetLocales);
		out.println("Target locale list where XF Sync is required: <br> ");
		for (String str : targetParentsList) {
			out.println(str + "<br>");
		}
		out.println("</br>");

		if (sourceXFPath != null) {
			Resource resource = null;
			ResourceResolver resourceResolver = mySiteResourceResolverService.getResourceResolver();
			resource = resourceResolver.getResource(sourceXFPath);
			if (resource != null) {
				for (String targetParent : targetParentsList) {
					try {
						Resource targetResource = resourceResolver.copy(sourceXFPath, targetParent);
						Resource sourceResource = targetResource;
						targetResource = resourceResolver.getResource(targetResource.getPath() + "/jcr:content");
						setMixinProperty(targetResource);
						targetResource.getResourceResolver().commit();

						Map<String, Object> properties = new HashMap<>();
						properties.put("jcr:primaryType", "cq:LiveCopy");
						properties.put("cq:master", sourceXFPath);
						properties.put("cq:isDeep", true);

						resourceResolver.create(targetResource, "cq:LiveSyncConfig", properties);
						Iterable<Resource> childResources = sourceResource.getChildren();

						for (Iterator<Resource> it = childResources.iterator(); it.hasNext();) {
							Resource childRes = it.next();
							if (!childRes.getPath().endsWith("jcr:content")) {
								childRes.adaptTo(Node.class).remove();
							}

						}
						resourceResolver.commit();
						response.getWriter()
								.println("<p style=\"color:green;\">Target <b>"
										+ targetResource.getPath().replace("/jcr:content", "")
										+ "</b> is created successfully.. <p>");
					} catch (Exception e) {
						e.printStackTrace();
						response.getWriter().println("<p style=\"color:red;\">" + e.getMessage() + "</p>");
						out.print(
								"Please verify target parent location is present or not OR check if the page you're trying sync is already exist..</br> ");
					}
				}

			} else {
				out.print(
						"</br></br><style='color:red'>Sorry! Please verify and provide valid source page path. Thank You. </style></br> ");
			}

		}

	}

	private List<String> getTargetedLocalePaths(String targetLocales) {
		List<String> targatedLocalePaths = new ArrayList<>();
		for (String locale : targetLocales.split(",")) {
			targatedLocalePaths.add(XF_LOCALE_ROOT_PATH + locale);
		}
		return targatedLocalePaths;
	}

	private void setMixinProperty(Resource post) {
		try {
			if (post != null) {
				Node postNode = post.adaptTo(Node.class);
				postNode.addMixin("cq:LiveRelationship");
			}
		} catch (Exception e) {
			LOGGER.error("Exception while getting the node in getTargetParents::setMixin {}", e.getMessage(), e);
		}
	}
}