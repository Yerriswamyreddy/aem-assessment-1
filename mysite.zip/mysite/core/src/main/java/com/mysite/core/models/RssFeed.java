package com.mysite.core.models;

public class RssFeed {

}
