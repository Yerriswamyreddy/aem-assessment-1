package com.mysite.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * 
 * Model is responsible to adopt manual feeds
 * 
 * @author yerriswamyreddyb
 *
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ManuallRssFeedModel extends RssFeed {

	@ValueMapValue(name = "title")
	private String title;

	@ValueMapValue(name = "date")
	private String date;

	@ValueMapValue(name = "description")
	private String description;

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getDate() {
		return date;
	}

}
