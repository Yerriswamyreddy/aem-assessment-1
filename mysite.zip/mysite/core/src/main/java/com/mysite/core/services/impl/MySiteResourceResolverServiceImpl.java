package com.mysite.core.services.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mysite.core.services.MySiteResourceResolverService;

/**
 * OSGI service which will return the service user to perform jcr operations
 * 
 * @author yerriswamyreddyb
 *
 */
@Component(service = MySiteResourceResolverService.class)
public class MySiteResourceResolverServiceImpl implements MySiteResourceResolverService {

	private static final Logger log = LoggerFactory.getLogger(MySiteResourceResolverServiceImpl.class);

	@Reference
	private ResourceResolverFactory resolverFactory;

	@Override
	public ResourceResolver getResourceResolver() {
		ResourceResolver resourceResolver = null;
		try {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, "mysite-subservice");
			resourceResolver = resolverFactory.getServiceResourceResolver(param);
		} catch (LoginException e) {
			log.error("LoginException{}", e);
		}
		return resourceResolver;
	}

	@Override
	public void closeResourceResolver(ResourceResolver resolver) {
		if (null != resolver && resolver.isLive()) {
			resolver.close();
		}
	}

}
