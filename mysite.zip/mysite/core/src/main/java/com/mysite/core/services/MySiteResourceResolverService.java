package com.mysite.core.services;

import org.apache.sling.api.resource.ResourceResolver;

public interface MySiteResourceResolverService {

	public ResourceResolver getResourceResolver();

	public void closeResourceResolver(ResourceResolver resolver);
}