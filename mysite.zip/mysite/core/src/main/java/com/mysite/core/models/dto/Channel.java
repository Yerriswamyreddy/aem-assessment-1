package com.mysite.core.models.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class Channel {
	@XmlElement(name = "title")
	private String title;

	@XmlElement(name = "link")
	private String link;

	@XmlElement(name = "description")
	private String description;

	@XmlElement(name = "item")
	private List<Item> items;

	public String getTitle() {
		return title;
	}

	public String getLink() {
		return link;
	}

	public String getDescription() {
		return description;
	}

	public List<Item> getItems() {
		return items;
	}

}
