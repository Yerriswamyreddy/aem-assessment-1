package com.mysite.core.models.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "rss")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Rss {
	@XmlElement(name = "channel")
	private Channel channel;

	@XmlAttribute(name = "xmlns:a10")
	private String a10;

	@XmlAttribute(name = "version")
	private double version;

	public Channel getChannel() {
		return channel;
	}

	public String getA10() {
		return a10;
	}

	public double getVersion() {
		return version;
	}

}
