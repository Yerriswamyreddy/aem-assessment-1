package com.mysite.core.services;

import java.util.List;

import com.mysite.core.models.RssFeed;

public interface AutoRssFeedService {

	List<RssFeed> getUpdates(String sourceUrl);
}
