package com.mysite.core.models.dto;

import javax.xml.bind.annotation.XmlElement;

public class Item {

	@XmlElement(name = "guid")
	private Guid guid;

	@XmlElement(name = "link")
	private String link;

	@XmlElement(name = "title")
	private String title;

	@XmlElement(name = "description")
	private String description;

	@XmlElement(name = "updated", namespace = "http://www.w3.org/2005/Atom")
	private String updated;

	public Guid getGuid() {
		return guid;
	}

	public String getLink() {
		return link;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getUpdated() {
		return updated;
	}

}
