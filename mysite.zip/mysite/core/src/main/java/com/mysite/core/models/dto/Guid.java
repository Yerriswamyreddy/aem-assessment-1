package com.mysite.core.models.dto;

public class Guid {
	private boolean isPermaLink;
	private int text;

	public boolean isPermaLink() {
		return isPermaLink;
	}

	public int getText() {
		return text;
	}

}
