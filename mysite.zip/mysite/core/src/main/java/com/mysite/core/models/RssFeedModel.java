package com.mysite.core.models;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.mysite.core.services.AutoRssFeedService;

/**
 * Model responsible to return feeds based on external url or manual fields
 * 
 * @author yerriswamyreddyb
 *
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, adapters = {
		RssFeedModel.class }, resourceType = {
				RssFeedModel.RESOURCE_TYPE }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class RssFeedModel {

	protected static final String RESOURCE_TYPE = "mysite/components/rssfeed";

	@OSGiService
	private AutoRssFeedService rssAutoFeedService;

	@ValueMapValue
	@Default(values = "4")
	private String noOfFeeds;

	@ValueMapValue
	private String sourceURL;

	@ChildResource
	private List<ManuallRssFeedModel> manualFeeds;

	public List<? extends RssFeed> getFeeds() {
		int feedRestriction = Integer.parseInt(noOfFeeds);
		List<RssFeed> feeds = new ArrayList<>();
		boolean isAutoFeeds = false;
		if (StringUtils.isNotBlank(sourceURL)) {
			feeds = rssAutoFeedService.getUpdates(sourceURL);
			if (CollectionUtils.isNotEmpty(feeds) && feeds.size() >= feedRestriction) {
				isAutoFeeds = true;
				return feeds.subList(0, feedRestriction);
			}
		}
		if (!isAutoFeeds && CollectionUtils.isNotEmpty(manualFeeds) && manualFeeds.size() >= feedRestriction) {
			return manualFeeds.subList(0, feedRestriction);
		}
		return feeds;
	}

}
